/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Shield, 
  Target, 
  Zap, 
  Users, 
  ArrowRight, 
  CheckCircle2, 
  Instagram, 
  MessageCircle,
  Menu,
  X,
  AlertTriangle,
  Flag,
  Search,
  FileText,
  ShieldCheck,
  HelpCircle,
  Lock,
  ChevronDown
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero Entrance
      gsap.from('.hero-title', {
        y: 100,
        opacity: 0,
        duration: 1.2,
        ease: 'power4.out',
        stagger: 0.2
      });

      gsap.from('.hero-sub', {
        opacity: 0,
        y: 20,
        duration: 1,
        delay: 0.8,
        ease: 'power3.out'
      });

      gsap.from('.hero-cta', {
        opacity: 0,
        scale: 0.8,
        duration: 1,
        delay: 1.2,
        ease: 'back.out(1.7)'
      });

      // Scroll Reveals
      gsap.utils.toArray('.reveal').forEach((elem: any) => {
        gsap.from(elem, {
          scrollTrigger: {
            trigger: elem,
            start: 'top 85%',
            toggleActions: 'play none none none'
          },
          y: 50,
          opacity: 0,
          duration: 1,
          ease: 'power3.out'
        });
      });
    });

    return () => ctx.revert();
  }, []);

  const whatsappLink = "https://wa.me/14073266600";
  const logoUrl = "https://lh3.googleusercontent.com/d/1fEc--qh99n-6tfc58bhxqsdpY6YXYSr6";
  const heroBgUrl = "https://lh3.googleusercontent.com/d/1rjYFq6gKV2IhkHHSh2wZl73_SYUpGqXI";

  const faqData = [
    {
      q: "Imigrante realmente pode ter arma nos Estados Unidos?",
      a: "Sim. O Gun Control Act de 1968 garante esse direito para imigrantes com status legal, sem histórico criminal e com documentação em ordem. Não é opinião. É lei federal americana."
    },
    {
      q: "Qual visto é aceito?",
      a: "Visto de turismo, estudo, trabalho, investimento ou família. Nossa orientação começa com uma análise do seu perfil específico para confirmar sua elegibilidade antes de qualquer passo."
    },
    {
      q: "Quanto tempo leva o processo?",
      a: "A posse pode ser resolvida em poucos dias. O porte tem um processo específico que conduzimos do início ao fim — com prazo médio de 2 a 4 semanas dependendo do seu perfil."
    },
    {
      q: "Por que eu pagaria por isso se posso tentar fazer sozinho?",
      a: "Você pode tentar fazer sozinho. Mas um erro no processo pode resultar em negação permanente, histórico criminal ou complicações sérias no seu visto de imigração. Nossos clientes não pagam apenas pelo processo. Pagam pela certeza de que vai dar certo na primeira vez — e pela tranquilidade de não colocar seu status legal e seu futuro nos Estados Unidos em risco."
    },
    {
      q: "Preciso falar inglês?",
      a: "Não. Conduzimos todo o processo em português — inclusive o acompanhamento presencial nas lojas, órgãos e treinamentos. Você não precisa entender de lei nem de inglês. Precisa apenas decidir que quer se proteger."
    },
    {
      q: "É seguro? Posso me complicar legalmente?",
      a: "Nosso trabalho começa exatamente em garantir que tudo seja feito dentro da lei. Nenhum cliente nosso teve qualquer problema legal ao longo do processo."
    }
  ];

  return (
    <div className="min-h-screen selection:bg-moss selection:text-white">
      {/* HEADER */}
      <header className="fixed top-0 left-0 w-full z-50 transition-all duration-300 glass border-b-0">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex flex-col">
              <div className="flex items-baseline gap-1">
                <span className="font-display text-2xl tracking-tighter uppercase font-extrabold leading-none">
                  BARS
                </span>
                <span className="font-display text-2xl tracking-tighter uppercase font-extrabold leading-none text-moss">
                  GROUP
                </span>
                <span className="font-display text-[10px] tracking-widest uppercase font-black leading-none opacity-40 ml-0.5">
                  INC
                </span>
              </div>
              <span className="text-[7px] uppercase tracking-[0.2em] text-cream/40 font-bold mt-1">
                BARE ARMS RESEARCH & SOLUTIONS
              </span>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-8 text-[10px] font-bold uppercase tracking-widest">
            <a href="#home" className="hover:text-moss transition-colors">Início</a>
            <a href="#problema" className="hover:text-moss transition-colors">O Problema</a>
            <a href="#servicos" className="hover:text-moss transition-colors">Serviços</a>
            <a href="#oferta" className="hover:text-moss transition-colors">Processo</a>
            <a href="#faq" className="hover:text-moss transition-colors">FAQ</a>
          </nav>

          <div className="flex items-center gap-4">
            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-2 bg-cream text-dark px-6 py-2.5 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-moss hover:text-white transition-all duration-300"
            >
              Consultoria <ArrowRight size={14} />
            </a>
            <button 
              className="lg:hidden text-cream"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden glass absolute top-20 left-0 w-full p-6 flex flex-col gap-4 animate-in fade-in slide-in-from-top-4">
            <a href="#home" className="text-xs uppercase tracking-widest font-bold" onClick={() => setIsMenuOpen(false)}>Início</a>
            <a href="#problema" className="text-xs uppercase tracking-widest font-bold" onClick={() => setIsMenuOpen(false)}>O Problema</a>
            <a href="#servicos" className="text-xs uppercase tracking-widest font-bold" onClick={() => setIsMenuOpen(false)}>Serviços</a>
            <a href="#oferta" className="text-xs uppercase tracking-widest font-bold" onClick={() => setIsMenuOpen(false)}>Processo</a>
            <a href="#faq" className="text-xs uppercase tracking-widest font-bold" onClick={() => setIsMenuOpen(false)}>FAQ</a>
            <a href={whatsappLink} className="bg-moss text-white p-4 rounded-xl text-center font-bold uppercase tracking-widest text-xs">Falar com Especialista</a>
          </div>
        )}
      </header>

      {/* SESSÃO 1 — HERO */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden pt-20" ref={heroRef}>
        <div className="absolute inset-0 z-0">
          <img 
            src={heroBgUrl} 
            alt="Tactical Background"
            className="w-full h-full object-cover opacity-50"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-dark via-dark/40 to-dark"></div>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass mb-8 animate-pulse">
            <span className="w-2 h-2 bg-moss rounded-full"></span>
            <span className="text-[10px] uppercase tracking-[0.2em] font-bold">Especialistas em Legislação Americana</span>
          </div>
          
          <h1 className="hero-title font-display text-6xl md:text-8xl lg:text-9xl font-extrabold leading-[0.9] tracking-tighter mb-6 text-gradient uppercase">
            SUA SEGURANÇA.<br />SEU DIREITO.
          </h1>
          
          <p className="hero-sub max-w-2xl mx-auto text-lg md:text-xl text-cream/70 mb-10 font-light leading-relaxed">
            Consultoria estratégica em porte, posse e licenças de caça nos Estados Unidos, conduzida com excelência, discrição e rigor legal.
          </p>

          <div className="hero-cta flex flex-col sm:flex-row items-center justify-center gap-4">
            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative flex items-center gap-3 bg-moss text-white px-10 py-5 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-white hover:text-dark transition-all duration-500 overflow-hidden"
            >
              <span className="relative z-10">→ Falar com um Especialista</span>
              <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
            </a>
            <a href="#servicos" className="text-[10px] font-bold uppercase tracking-widest hover:text-moss transition-colors flex items-center gap-2">
              Ver serviços ↓
            </a>
          </div>
        </div>
      </section>

      {/* SESSÃO 2 — SERVIÇOS */}
      <section id="servicos" className="py-24 bg-tactical-gray/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="reveal">
              <span className="text-moss font-bold uppercase tracking-[0.3em] text-[10px] mb-4 block">Nossa Expertise</span>
              <h2 className="font-display text-4xl md:text-6xl font-bold uppercase tracking-tighter mb-12">
                SOLUÇÕES COMPLETAS<br />PARA SUA SEGURANÇA
              </h2>
              
              <div className="space-y-10">
                <div className="flex gap-6 group">
                  <div className="mt-1">
                    <CheckCircle2 className="text-moss" size={28} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold uppercase tracking-tight mb-3">PORTE E POSSE DE ARMA</h4>
                    <p className="text-cream/50 text-sm leading-relaxed max-w-md">
                      Orientação completa sobre as leis estaduais e federais para aquisição legal de armamento.
                    </p>
                  </div>
                </div>
                <div className="flex gap-6 group">
                  <div className="mt-1">
                    <CheckCircle2 className="text-moss" size={28} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold uppercase tracking-tight mb-3">LICENÇA DE CAÇA (HUNTING LICENSE)</h4>
                    <p className="text-cream/50 text-sm leading-relaxed max-w-md">
                      Tudo o que você precisa para obter sua licença e praticar caça esportiva legalmente nos Estados Unidos.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-16">
                <a 
                  href={whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 bg-cream text-dark px-10 py-5 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-moss hover:text-white transition-all duration-300"
                >
                  → CONSULTAR AGORA
                </a>
              </div>
            </div>

            <div className="relative reveal">
              <div className="aspect-[4/5] rounded-[40px] overflow-hidden border border-white/10">
                <img 
                  src="https://lh3.googleusercontent.com/d/1NykOtYiElpHzY3b437fhgm2dsvh46kmj" 
                  alt="Bars Group Tactical" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-10 -left-10 glass p-8 rounded-3xl max-w-[280px] hidden md:block">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-10 h-10 rounded-full bg-moss flex items-center justify-center">
                    <ShieldCheck size={20} />
                  </div>
                  <span className="font-bold text-xs uppercase tracking-tight">100% Legalizado</span>
                </div>
                <p className="text-[10px] text-cream/60 leading-relaxed uppercase tracking-widest">
                  Processos conduzidos sob as normas do ATF e legislações federais.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SESSÃO 3 — O PROBLEMA */}
      <section id="problema" className="py-24 px-6 max-w-5xl mx-auto">
        <div className="reveal text-center mb-16">
          <span className="text-moss font-bold uppercase tracking-[0.3em] text-[10px] mb-4 block">A REALIDADE QUE NINGUÉM CONTA</span>
          <h2 className="font-display text-4xl md:text-6xl font-bold uppercase tracking-tighter mb-8">
            Morar nos Estados Unidos é incrível.<br />
            <span className="text-cream/40">Mas os Estados Unidos também têm outra realidade.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
          <div className="reveal space-y-6 text-cream/70 leading-relaxed">
            <p>Situações de risco acontecem em estacionamentos, postos de gasolina, shoppings —</p>
            <p className="text-cream font-bold">Em plena luz do dia. Com famílias ao redor.</p>
            <p>E quando isso acontece, você tem segundos para reagir.</p>
            <p>A pergunta não é se você vai precisar se defender um dia.</p>
            <p className="text-2xl font-display font-bold text-cream uppercase tracking-tight">A pergunta é: Você vai estar preparado?</p>
          </div>

          <div className="reveal glass p-8 rounded-[32px] border-moss/20">
            <h4 className="text-moss font-bold uppercase tracking-widest text-xs mb-6">Se você já pensou em se armar legalmente mas...</h4>
            <ul className="space-y-4 text-sm">
              {[
                "Pesquisou no Google, achou 50 respostas diferentes em inglês que mal entende.",
                "Tem medo de errar no processo e se complicar legalmente — colocando em risco seu visto.",
                "Conhece alguém que tentou fazer sozinho e se complicou.",
                "Não tem tempo para navegar numa burocracia que não fala português.",
                "Ainda acredita que imigrante não pode ter arma nos EUA."
              ].map((item, i) => (
                <li key={i} className="flex gap-3">
                  <span className="text-moss">→</span>
                  <span className="text-cream/60">{item}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8 pt-8 border-t border-white/5">
              <p className="text-cream font-bold uppercase tracking-widest text-xs">Se você se identificou com pelo menos um desses pontos —</p>
              <p className="text-moss font-bold uppercase tracking-widest text-sm mt-2">Você está no lugar certo.</p>
            </div>
          </div>
        </div>
      </section>

      {/* SESSÃO 4 — A VIRADA */}
      <section className="py-24 bg-tactical-gray/40 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="reveal order-2 lg:order-1">
            <div className="aspect-video rounded-[32px] overflow-hidden border border-white/10 shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1508433957232-3107f5fd5995?q=80&w=1200&auto=format&fit=crop" 
                alt="USA Flag" 
                className="w-full h-full object-cover opacity-80"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          
          <div className="reveal order-1 lg:order-2">
            <span className="text-moss font-bold uppercase tracking-[0.3em] text-[10px] mb-4 block">O QUE A LEI AMERICANA GARANTE</span>
            <h2 className="font-display text-4xl md:text-6xl font-bold uppercase tracking-tighter mb-8">
              Imigrante legal tem o direito de se armar nos Estados Unidos.
            </h2>
            <div className="space-y-6 text-cream/60">
              <p className="text-cream font-bold uppercase tracking-widest text-xs">Isso não é opinião. É lei federal americana.</p>
              <p>De acordo com o <span className="text-cream">Gun Control Act de 1968</span> e a legislação federal americana, imigrantes com status legal têm o direito garantido de adquirir e possuir armas de fogo nos EUA.</p>
              <div className="grid grid-cols-2 gap-4 text-[10px] font-bold uppercase tracking-widest text-moss">
                <span>Visto de turismo</span>
                <span>Visto de estudo</span>
                <span>Visto de trabalho</span>
                <span>Visto de investimento</span>
                <span>Visto de família</span>
              </div>
              <p>Se você tem documentação em ordem e zero histórico criminal — <span className="text-cream">Você tem esse direito.</span></p>
              <p>O problema nunca foi a lei te impedir. O problema foi nunca ter alguém de confiança para te guiar pelo processo correto — em português. Sem risco. Do início ao fim.</p>
              <p className="text-moss font-bold uppercase tracking-widest text-sm">É exatamente isso que a Bars Group faz.</p>
            </div>
          </div>
        </div>
      </section>

      {/* SESSÃO 5 — PARA QUEM É */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="reveal glass p-10 rounded-[40px] border-moss/30">
            <span className="text-moss font-bold uppercase tracking-[0.3em] text-[10px] mb-6 block">ESSE SERVIÇO É PARA VOCÊ SE...</span>
            <ul className="space-y-6">
              {[
                "Você é imigrante legal nos EUA",
                "Quer proteger sua família e seu patrimônio com uma arma legal em casa",
                "Nunca passou pelo processo e não sabe por onde começar",
                "Quer fazer tudo dentro da lei sem colocar seu visto ou seu futuro em risco",
                "Valoriza discrição, profissionalismo e resultado desde o primeiro contato",
                "Entende que segurança é um investimento — não um gasto"
              ].map((item, i) => (
                <li key={i} className="flex gap-4 items-start">
                  <CheckCircle2 className="text-moss shrink-0" size={20} />
                  <span className="text-cream/80 text-sm font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="reveal glass p-10 rounded-[40px] border-red-900/20 bg-red-950/5">
            <span className="text-red-500 font-bold uppercase tracking-[0.3em] text-[10px] mb-6 block">ESSE SERVIÇO NÃO É PARA VOCÊ SE...</span>
            <ul className="space-y-6">
              {[
                "Você não tem status legal de imigrante nos EUA",
                "Tem histórico criminal de qualquer natureza",
                "Busca atalhos fora da lei",
                "Não valoriza um processo conduzido com rigor e responsabilidade"
              ].map((item, i) => (
                <li key={i} className="flex gap-4 items-start">
                  <X className="text-red-500 shrink-0" size={20} />
                  <span className="text-cream/40 text-sm font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* SESSÃO 6 — A OFERTA */}
      <section id="oferta" className="py-24 bg-tactical-gray/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="reveal text-center mb-20">
            <span className="text-moss font-bold uppercase tracking-[0.3em] text-[10px] mb-4 block">COMO FUNCIONA</span>
            <h2 className="font-display text-4xl md:text-6xl font-bold uppercase tracking-tighter mb-6">
              Um processo completo.<br />
              <span className="text-cream/40">Do zero até você armado legalmente.</span>
            </h2>
            <p className="text-cream/60 max-w-2xl mx-auto uppercase tracking-widest text-[10px] font-bold">
              Cada etapa foi desenhada para que você não precise entender de lei, não precise falar inglês e não corra nenhum risco.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                step: "ETAPA 1",
                title: "ORIENTAÇÃO INICIAL",
                icon: <Search size={32} />,
                desc: "Você sai dessa etapa sabendo exatamente o que pode fazer com base no seu visto e perfil legal específico. Zero dúvida. Zero risco. Zero achismo."
              },
              {
                step: "ETAPA 2",
                title: "DOCUMENTAÇÃO COMPLETA",
                icon: <FileText size={32} />,
                desc: "Sua documentação chega perfeita na primeira vez. Sem rejeição. Sem retrabalho. Sem stress com burocracia em inglês."
              },
              {
                step: "ETAPA 3",
                title: "AQUISIÇÃO DA ARMA",
                icon: <Target size={32} />,
                desc: "Você escolhe a arma certa para o seu perfil com quem realmente entende de armamento. Acompanhamento presencial e orientação completa."
              },
              {
                step: "ETAPA 4",
                title: "PORTE APROVADO",
                icon: <ShieldCheck size={32} />,
                desc: "Você sai com seu porte aprovado e treinamento completo para usar com segurança e responsabilidade. 100% dentro da lei."
              }
            ].map((item, i) => (
              <div key={i} className="glass p-8 rounded-[32px] hover:border-moss/50 transition-all duration-500 group">
                <div className="text-moss mb-6 group-hover:scale-110 transition-transform duration-500">{item.icon}</div>
                <span className="text-moss font-bold text-[10px] tracking-[0.3em] mb-2 block">{item.step}</span>
                <h4 className="text-lg font-bold uppercase tracking-tight mb-4">{item.title}</h4>
                <p className="text-cream/50 text-xs leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-16 reveal glass p-8 rounded-[32px] text-center border-moss/20">
            <p className="text-cream/70 text-sm italic">
              "Você entra no processo sem saber por onde começar. Você sai com sua posse, seu porte e a tranquilidade de quem fez tudo certo desde o primeiro passo."
            </p>
            <div className="mt-8">
              <a 
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 bg-moss text-white px-10 py-5 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-white hover:text-dark transition-all duration-500"
              >
                → QUERO COMEÇAR MEU PROCESSO
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* SESSÃO 7 — PROVA SOCIAL */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="reveal text-center mb-20">
          <span className="text-moss font-bold uppercase tracking-[0.3em] text-[10px] mb-4 block">O QUE DIZEM NOSSOS CLIENTES</span>
          <h2 className="font-display text-4xl md:text-6xl font-bold uppercase tracking-tighter mb-4">
            Brasileiros que decidiram se preparar —<br />
            <span className="text-cream/40">e não se arrependeram.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              name: "Carlos Mendes",
              role: "Empresário — Orlando, FL",
              text: "Tentei fazer sozinho por quase 3 meses e não saí do lugar. Com a Bars Group resolvi tudo em menos de 2 semanas. Hoje tenho minha posse e meu porte — e a certeza de que fiz tudo certo."
            },
            {
              name: "Ricardo Silva",
              role: "Imigrante legal — Miami, FL",
              text: "Eu achava que como imigrante nunca poderia ter uma arma nos Estados Unidos. A Bars Group me mostrou que eu tinha esse direito o tempo todo — e me guiou em cada etapa do processo. Em 12 dias estava com minha licença em mãos."
            },
            {
              name: "André Costa",
              role: "Empresário — Tampa, FL",
              text: "O que mais me surpreendeu foi a discrição e o profissionalismo desde o primeiro contato. Fui acompanhado em cada etapa. Hoje durmo tranquilo sabendo que minha família está protegida dentro da lei."
            }
          ].map((item, i) => (
            <div key={i} className="glass p-10 rounded-[32px] flex flex-col justify-between reveal">
              <p className="text-cream/70 italic mb-8 text-sm leading-relaxed">"{item.text}"</p>
              <div>
                <h5 className="font-bold text-sm uppercase tracking-tight">{item.name}</h5>
                <span className="text-[10px] text-moss font-bold uppercase tracking-widest">{item.role}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SESSÃO 8 — FAQ */}
      <section id="faq" className="py-24 bg-tactical-gray/10">
        <div className="max-w-4xl mx-auto px-6">
          <div className="reveal text-center mb-16">
            <span className="text-moss font-bold uppercase tracking-[0.3em] text-[10px] mb-4 block">PERGUNTAS FREQUENTES</span>
            <h2 className="font-display text-4xl md:text-6xl font-bold uppercase tracking-tighter">
              Tudo que você precisa saber antes de começar.
            </h2>
          </div>

          <div className="space-y-4 reveal">
            {faqData.map((item, i) => (
              <div key={i} className="glass rounded-2xl overflow-hidden">
                <button 
                  className="w-full p-6 text-left flex justify-between items-center hover:bg-white/5 transition-colors"
                  onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                >
                  <span className="font-bold text-sm uppercase tracking-tight flex gap-3">
                    <HelpCircle className="text-moss shrink-0" size={18} />
                    {item.q}
                  </span>
                  <ChevronDown className={`text-moss transition-transform duration-300 ${activeFaq === i ? 'rotate-180' : ''}`} size={20} />
                </button>
                <div className={`transition-all duration-300 ease-in-out overflow-hidden ${activeFaq === i ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
                  <div className="p-6 pt-0 text-cream/50 text-sm leading-relaxed border-t border-white/5">
                    {item.a}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SESSÃO 9 — CTA FINAL */}
      <section className="py-24 px-6">
        <div className="max-w-5xl mx-auto glass rounded-[48px] p-12 md:p-24 text-center relative overflow-hidden reveal">
          <div className="absolute top-0 right-0 w-96 h-96 bg-moss/10 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2"></div>
          
          <div className="relative z-10">
            <span className="text-moss font-bold uppercase tracking-[0.3em] text-[10px] mb-6 block">O PRÓXIMO PASSO É SEU</span>
            <h2 className="font-display text-4xl md:text-7xl font-bold uppercase tracking-tighter mb-8 leading-none">
              Sua família merece estar protegida.<br />
              <span className="text-moss">Você tem esse direito.</span>
            </h2>
            <div className="text-cream/60 max-w-2xl mx-auto mb-12 text-sm space-y-4">
              <p>Atendemos um número limitado de clientes por mês para garantir atenção individualizada em cada caso.</p>
              <p>Se você chegou até aqui — é porque você já sabe que precisa fazer isso.</p>
              <p className="text-cream font-bold uppercase tracking-widest text-xs">A única coisa entre você e a segurança da sua família é dar o primeiro passo.</p>
            </div>

            <div className="flex flex-col items-center gap-6">
              <a 
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-4 bg-moss text-white px-12 py-6 rounded-full text-xs font-bold uppercase tracking-[0.2em] hover:bg-white hover:text-dark transition-all duration-500 shadow-2xl shadow-moss/20"
              >
                → GARANTIR MINHA VAGA AGORA
              </a>
              <a href={whatsappLink} className="text-[10px] font-bold uppercase tracking-widest text-cream/40 hover:text-moss transition-colors flex items-center gap-2">
                Falar pelo WhatsApp ↓
              </a>
            </div>

            <div className="mt-16 pt-12 border-t border-white/5 grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="flex flex-col items-center gap-2">
                <Lock size={16} className="text-moss" />
                <span className="text-[8px] font-bold uppercase tracking-widest text-cream/40">Processo 100% legal</span>
              </div>
              <div className="flex flex-col items-center gap-2">
                <Flag size={16} className="text-moss" />
                <span className="text-[8px] font-bold uppercase tracking-widest text-cream/40">Legislação Americana</span>
              </div>
              <div className="flex flex-col items-center gap-2">
                <MessageCircle size={16} className="text-moss" />
                <span className="text-[8px] font-bold uppercase tracking-widest text-cream/40">Apoio em Português</span>
              </div>
              <div className="flex flex-col items-center gap-2">
                <Zap size={16} className="text-moss" />
                <span className="text-[8px] font-bold uppercase tracking-widest text-cream/40">Vagas Limitadas</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-20 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="flex items-center gap-4">
            <div className="flex flex-col">
              <div className="flex items-baseline gap-1">
                <span className="font-display text-xl tracking-tighter uppercase font-extrabold leading-none">
                  BARS
                </span>
                <span className="font-display text-xl tracking-tighter uppercase font-extrabold leading-none text-moss">
                  GROUP
                </span>
                <span className="font-display text-[8px] tracking-widest uppercase font-black leading-none opacity-30 ml-0.5">
                  INC
                </span>
              </div>
              <span className="text-[6px] uppercase tracking-[0.2em] text-cream/20 font-bold mt-1">
                BARE ARMS RESEARCH & SOLUTIONS
              </span>
            </div>
          </div>

          <div className="flex gap-8">
            <a href="https://www.instagram.com/gbrsgroup/" target="_blank" rel="noopener noreferrer" className="text-cream/40 hover:text-moss transition-colors">
              <Instagram size={20} />
            </a>
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="text-cream/40 hover:text-moss transition-colors">
              <MessageCircle size={20} />
            </a>
          </div>

          <p className="text-[8px] text-cream/20 uppercase tracking-[0.3em] font-bold">
            Copyright © 2026 Bars Group Inc. Todos os direitos reservados.
          </p>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a 
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-8 right-8 z-50 w-16 h-16 bg-moss text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300 group"
      >
        <MessageCircle size={28} />
        <span className="absolute right-full mr-4 bg-white text-dark px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
          Falar no WhatsApp
        </span>
      </a>
    </div>
  );
}
